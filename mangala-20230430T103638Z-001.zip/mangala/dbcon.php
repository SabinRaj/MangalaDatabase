<?php
$con = mysqli_connect('localhost','root','','mangala');
if($con == false){
	echo "connection failed";
}
?>