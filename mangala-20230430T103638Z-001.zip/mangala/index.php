<!DOCTYPE html>
<html>
  <head>
    <title>mangala</title>
    <style>
    body{
    font-family: sans-serif;
    color: red;
    }
    h1{
    font-size: 50px;
    color: red;
    text-shadow: 5px 8px 12px green;
    text-align: center;
    top: 1%
    }
    h2{
    font-size: 30px;
    color: red;
    text-shadow: 5px 8px 12px green;
    text-align: center;
    }
    table{
    background-color: #99c2ff;
    margin-top: 1px;
    }
    </style>
  </head>
  <body background="img/b.jpg" style="background-repeat: no-repeat; background-size:cover" >
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4 col-sm-12 col-xs-12 col-12 p-2" >
          
          <a href="login.php" style="float:right;">
            <img src="img/admin.png" alt="ADMIN!" height="70px" width="110px">
          </a>
          <h1 align="center"><b>WELCOME TO MANGALA HSS</b></h1>
          <h2 align="center"><b> MadhyaNepal Municipality-4<br>Sotipasal,Lamjung</b></h2>
          <table align="center" border="1">
            <form action="index.php" method="post" accept-charset="utf-8" >
              <tr>
                <th colspan="2">Donation Information</th>
              </tr>
              <tr>
                <th>Enter Name:</th>
                <td><input type="text" name="name" placeholder="Enter name to search" required /></td></tr><tr>
                <th>Enter Perm Address:</th>
                <td><input type="text" name="permaddr" placeholder="Enter perm address" /></td></tr>
                <tr><td align="center"><button onclick="location.href='view.php'" type="button">
                  ViewAll</button></td><td align="center"><input type="submit" name="submit" value="Search"></td></tr>
                </form>
              </table>
              <br><br><br>
              <br>
              <a href="index.php" style="float:left;">
                <img src="img/home.png" alt="Home" height="70px" width="120px">
              </a>
              <br><br><br>
              <br>
              <?php
              if(isset($_POST['submit']))
              {
              include('dbcon.php');
              $name=$_POST['name'];
              $permaddr=$_POST['permaddr'];
              $qry="SELECT * FROM `doner` WHERE `name` LIKE '%$name%' AND `permaddr` LIKE '%$permaddr%' ";
              $run=mysqli_query($con,$qry);
              if(mysqli_num_rows($run)<1)
              {
              ?>
              <script>
              alert('data not found!!!')
              </script>
              <?php
              
              }
              else
              {
              $count=0;
              while($data=mysqli_fetch_assoc($run))
              {
              $count++;
              ?>
              <table align="center" border="1">
                <tr>
                  <th>Name</th>
                  <td><?php echo $data['name']; ?></td>
                </tr>
                <tr>
                  <th>Permanent Address</th>
                  <td><?php echo $data['permaddr']; ?></td>
                </tr>
                <tr>
                  <th>Temprory Address</th>
                  <td><?php echo $data['tempaddr']; ?></td>
                </tr>
                <tr>
                  <th>Total Amount</th>
                  <td><?php echo $data['amount'];   ?></td>
                </tr><tr>
                  <th>Date</th>
                  <td><?php echo $data['date'];   ?></td>
                </tr><tr>
                <th>Contact Number</th>
                <td><?php echo $data['contactno'];?></td>
              </tr><tr>
              <th>Father Name</th>
              <td><?php echo $data['fname']; ?></td>
            </tr><tr>
            <th>Mother Name</th>
            <td><?php echo $data['mname']; ?></td>
          </tr>
        </table>
        <br><br>
      </div>
    </div>
  </div>
  <?php
  }
  }
  }
  ?>
</body>
</html>