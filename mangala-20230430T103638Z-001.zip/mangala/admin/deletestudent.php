<?php
session_start();
if(isset($_SESSION['uid']))
{
echo "";
}
else
{
header('location: ../login.php');
}
?>
<?php
include('header.php');
?>
<br><br>
<table align="center">
    <form action="deletestudent.php" method="post" accept-charset="utf-8">
        <tr>
            <th>Enter Name:</th>
            <td><input type="text" name="name" placeholder="Enter name to search" required /></td>
            <th>Enter Perm Address:</th>
            <td><input type="text" name="permaddr" placeholder="Enter perm address" /></td>
            <td colspan="2"><input type="submit" name="submit" value="Search"></td>
        </tr>
    </form>
</table>
<table align="center" width="85%" border="1" >
    
    <tr>
        <th>NO.</th>
        <th>Name</th>
        <th>Perm Address</th>
        <th>Temp Address</th>
        <th>Amount</th>
        <th>Date</th>
        <th>Contact No.</th>
        <th>Father's Name</th>
        <th>Mother's Name</th>
        <th>Edit</th>
    </tr>
    <br>
    <?php
    if(isset($_POST['submit']))
    {
    include('../dbcon.php');
    $name=$_POST['name'];
    $permaddr=$_POST['permaddr'];
    $qry="SELECT * FROM `doner` WHERE `name` LIKE '%$name%' AND `permaddr` LIKE '%$permaddr%' ";
    $run=mysqli_query($con,$qry);
    if(mysqli_num_rows($run)<1)
    {
    echo"<tr><td colspan=9>NO RECORD FOUNDS!!!</tr></td>";
    }
    else
    {
    $count=0;
    while($data=mysqli_fetch_assoc($run))
    {
    $count++;
    ?>
    <tr align="center">
        <td><?php echo $count;   ?></td>
        <td><?php echo $data['name']; ?></td>
        <td><?php echo $data['permaddr']; ?></td>
        <td><?php echo $data['tempaddr']; ?></td>
        <td><?php echo $data['amount'];   ?></td>
        <td><?php echo $data['date'];   ?></td>
        <td><?php echo $data['contactno'];?></td>
        <td><?php echo $data['fname']; ?></td>
        <td><?php echo $data['mname']; ?></td>
        <td><a href="deleteform.php?sid=<?php  echo $data['id'];  ?>">Delete</a></td>
    </tr>
    <?php
    }
    }
    }
    ?>
    
</table>