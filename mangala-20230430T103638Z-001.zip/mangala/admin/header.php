<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>mangala</title>
		<style>
			h1{
				font-size: 50px;
				color: red;
				text-shadow: 5px 8px 12px green;
				text-align: center;
				top: 1%
				}
				h2{
					font-size: 30px;
				color: red;
				text-shadow: 5px 8px 12px green;
				text-align: center;
				}
		</style>
	</head>
	<body background="../img/bgadmin.jpg" style="background-repeat: no-repeat; background-size: cover" >
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 col-xs-12 col-12 p-2" >
					<a href="logout.php" style="float:right; margin-right: 20px;"><img src="../img/logout.png" alt="logout" height="80px" width="130px"></a>
					<a href="admindash.php" style="float:left;">
						<img src="../img/admin.png" alt="ADMIN!" height="60px" width="90px">
					</a>
					<h1 align="center"><b>MANGALA HIGHER SECONDARY SCHOOL</b></h1>
					<h2 align="center"><b> MadhyaNepal Municipality-4<br>Sotipasal,Lamjung</b></h2>
				</div>
			</div>
		</div>
	</body>
</html>