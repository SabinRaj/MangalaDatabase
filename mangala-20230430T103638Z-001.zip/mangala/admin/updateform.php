<?php
session_start();
if(isset($_SESSION['uid']))
{
echo "";
}
else
{
header('location: ../login.php');
}
?>
<?php
include('header.php');
include('../dbcon.php');
$sid=$_GET['sid'];
$qry="SELECT * FROM `doner` WHERE `id`='$sid'";
$run=mysqli_query($con,$qry);
$data=mysqli_fetch_assoc($run);
?>
<form action="updatedata.php" method="post" accept-charset="utf-8">
	
	<table align="center" border="1" <style="width:70%; margin-top:40px; ">
				
		</style>>
		
		<tr>
			<th>Name</th>
			<td><input type="text" name="name" value=<?php  echo $data['name'];  ?> required></td>
		</tr>
		<tr>
			<th>Perm Address</th>
			<td><input type="text" name="permaddr" value=<?php  echo $data['permaddr'];  ?> required></td>
		</tr>
		<tr>
			<th>Temp Address</th>
			<td><input type="text" name="tempaddr" value=<?php  echo $data['tempaddr'];  ?> required></td>
		</tr>
		<tr>
			<th>Amount</th>
			<td><input type="number" name="amount" value=<?php  echo $data['amount'];  ?> required></td>
		</tr>
		<tr>
			<th>Date</th>
			<td><input type="date" name="date" value=<?php  echo $data['date'];  ?> required></td>
		</tr>
		<tr>
			<th>Contact Number</th>
			<td><input type="number" name="contactno" value=<?php  echo $data['contactno'];  ?> required></td>
		</tr>
		<tr>
			<th>Father Name</th>
			<td><input type="text" name="fname" value=<?php  echo $data['fname'];  ?> required></td>
		</tr>
		<tr>
			<th>Mother Name</th>
			<td><input type="text" name="mname" value=<?php  echo $data['mname'];  ?> required></td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="hidden" name="sid" value="<?php   echo $data['id']; ?>"/>
				<input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
	</form>