<?php
session_start();
if(isset($_SESSION['uid']))
{
	echo "";
}
else
{
	header('location: ../login.php');
}
?>
<?php
include('header.php');
?>
<form action="addstudent.php" method="post" accept-charset="utf-8">
	
	<table align="center" border="1" <style="width:70%; margin-top:40px; ">
				
		</style>
		
		<tr>
			<th>Name</th>
			<td><input type="text" name="name" placeholder="Enter Your Full Name." required></td>
		</tr>
		<tr>
			<th>Perm Address</th>
			<td><input type="text" name="permaddr" placeholder="Enter Your Perm Address" required></td>
		</tr>
		<tr>
			<th>Temp Address</th>
			<td><input type="text" name="tempaddr" placeholder="Enter Your Temp Address" required></td>
		</tr>
		<tr>
			<th>Amount</th>
			<td><input type="number" name="amount" placeholder="Enter Total Amount" required></td>
		</tr>
		<tr>
			<th>Date</th>
			<td><input type="date" name="date" placeholder="Enter Date" required></td>
		</tr>
		<tr>
			<th>Contact Number</th>
			<td><input type="number" name="contactno" placeholder="Enter Your Mobile Number" required></td>
		</tr>
		<tr>
			<th>Father Name</th>
			<td><input type="text" name="fname" placeholder="Enter Your Father Name" required></td>
		</tr>
		<tr>
			<th>Mother Name</th>
			<td><input type="text" name="mname" placeholder="Enter Your Mother Name" required></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="submit" value="Submit"></td>
		</tr>
	</table>
</form>
<?php
if(isset($_POST['submit']))
{
	include('../dbcon.php');
	$name=$_POST['name'];
	$permaddr=$_POST['permaddr'];
	$tempaddr=$_POST['tempaddr'];
	$amount=$_POST['amount'];
	$date=$_POST['date'];
	$contactno=$_POST['contactno'];
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$qry="INSERT INTO `doner`(`id`, `name`, `permaddr`, `tempaddr`, `amount`, `date`,`contactno`, `fname`, `mname`) VALUES (NULL,'$name','$permaddr','$tempaddr','$amount','$date','$contactno','$fname','$mname')";
	$run=mysqli_query($con,$qry);
	if($run==true)
	{
?>
<script>
	alert('data inserted.')
</script>
<?php
}
}
?>