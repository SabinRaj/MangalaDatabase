<!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <style>
    h1{
    font-size: 50px;
    color: red;
    text-shadow: 5px 8px 12px green;
    text-align: center;
    top: 1%
    }
    h2{
    font-size: 27px;
    color: red;
    text-shadow: 5px 8px 12px green;
    text-align: center;
    }
    .row{
    margin-top: 80px;
    margin-left: 90px;
    }
    </style>
  </head>
  <body>
    <body background="../img/bgadmin.jpg" style="background-repeat: no-repeat; background-size: cover" >
      <a href="logout.php" style="float:right; margin-right: 20px;"><img src="../img/logout.png" alt="logout" height="80px" width="130px"></a>
      <a href="admindash.php" style="float:left;">
        <img src="../img/admin.png" alt="ADMIN!" height="60px" width="90px">
      </a>
      <h1 align="center"><b>MANGALA HIGHER SECONDARY SCHOOL</b></h1>
      <!-- **********************Search address**************** -->
      <form action="viewalladdr.php" method="post" accept-charset="utf-8" align="right">
        <input type="text" name="permaddr" placeholder="Enter perm address" />
        <input type="submit" name="submit" value="Search">
      </form><br>
       <form action="viewalldate.php" method="post" accept-charset="utf-8" align="right">
        <input type="number" name="date" placeholder="Enter year" />
        <input type="submit" name="submit" value="Search">
      </form>
      <!--   ******************************* -->
      <h2 align="center"><b> MadhyaNepal Municipality-4<br>Sotipasal,Lamjung</b></h2>
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 col-sm-12 col-xs-12 col-12 p-2" >
            <a href="order.php" style="float:center; "><img src="../img/sortby.png" alt="sort by" height="150px" width="240px">
              <h2 style="margin-top: 5%;color: #800000;cursor:default;"><span style="padding-right: 70%; " id="containerp" title="Click on the Image :)" >SORT BY</span></h2>
            </a>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12 col-12 p-2" >
            <a href="viewalldoner.php" style="float:center; "><img src="../img/viewall.png" alt="viewall" height="150px" width="240px">
              <h2 style="margin-top: 5%;color: #800000;cursor:default;"><span style="padding-right: 70%; ;" id="containerp" title="Click on the Image :)" >VIEW ALL</span></h2>
            </a>
          </div>
        </div>
      </div>
    </body>
  </html>