<?php
include('../dbcon.php');
	$name=$_POST['name'];
	$permaddr=$_POST['permaddr'];
	$tempaddr=$_POST['tempaddr'];
	$amount=$_POST['amount'];
	$amount=$_POST['date'];
	$contactno=$_POST['contactno'];
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$id=$_POST['sid'];
	$qry="UPDATE `doner` SET  `name` = '$name', `permaddr` = '$permaddr', `tempaddr` = '$tempaddr', `amount` = '$amount', `contactno` = '$contactno', `fname` = '$fname', `mname` = '$mname' WHERE `id` = $id";
	$run=mysqli_query($con,$qry);
	if($run==true)
	{
?>
<script>
	alert('data updated successfully.')
window.open('updateform.php?sid=<?php echo $id; ?>','_self');
</script>
<?php
}
?>